<template>
<div>
   <div class="swiper_wrap " id='course-low-height'>
        <!-- <div class="bk" style="background-image: url(&quot;//img1.sycdn.imooc.com/5c9229900001b4e616000540.jpg&quot;);"> -->
    </div>
    <div class="body">

        <h3 class="types-title">
            <span class="tit-icon icon-shizhan-l tit-icon-l"></span>
            <span v-html='title'>
               
            </span>
         
            <!-- <em>小</em>／<em>学</em>／<em>一</em>／<em>年</em>／<em>级</em> -->
            <span class="tit-icon icon-shizhan-r tit-icon-r"></span>
        </h3>
        <div class="clearfix types-content" id='save-padding-left'>
            <div class="menu">
                <!-- <h1>年级分类</h1> -->
                <ul id="allClass">
                    <li v-for="(item,index) in stage" @click="getleavel(item.id,item.name)" :key='index'> <span><a >{{item.name}}</a></span>
                        <ol>
                            <dl>
                                <dt>
                                  <h2><em onclick="closeBox(this)">关闭</em>栏目分类</h2>
                                </dt>
                                <dd>
                                    <p><a href="javascript:">一年级</a></p>
                                    <p><a href="javascript:">二年级</a></p>
                                    <p><a href="javascript:">三年级</a></p>
                                    <p><a href="javascript:">四年级</a></p>
                                    <p><a href="javascript:">五年级</a></p>
                                    <p><a href="javascript:">六年级</a></p>
                                </dd>
                                <small>&nbsp;</small>
                            </dl>
                        </ol>
                    </li>
                  
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="index-card-container course-card-container container" v-for="(item,index) in courselist" :key='index'>
                <router-link to='/coursedetail' class="course-card" >
                    <div class="course-card-top hashadow">
                        <img class="course-banner" v-lazy="item.cover">


                        <div class="course-label">
                            <label>Vue.js</label>
                        </div>
                    </div>
                    <div class="course-card-content">
                        <h3 class="course-card-name"> {{item.name}}</h3>
                        <div class="clearfix course-card-bottom">
                            <div class="course-card-info">
                                <span>实战</span><span>中级</span><span><i class="icon-set_sns"></i>5148</span>
                                <span class="course-star-box"><i class="icon-star2 on"></i><i
                                        class="icon-star2 on"></i><i class="icon-star2 on"></i><i
                                        class="icon-star2 on"></i><i class="icon-star2 on"></i></span>
                            </div>


                            <div class="course-card-price sales">￥{{item.price}}

                                <span class="sales-tip">满减</span>

                            </div>
                        </div>
                    </div>
                </router-link>
            </div>


        </div>


    </div>


    <div class="left_tip">
        <ul>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
</div>
</template>
<script>
export default {
     data() {
    return {
                title:' <em>一</em>／<em>年</em>／<em>级</em>',
                filterimg: '1111',
                stage:[],
                courselist:[]
    }
     },
     methods:{
getstage(){
                   
                    this.$http.get('cloud/level/getStage')
                        .then( (response)=> {
                            this.stage = response.data.data.reverse();
                             this.getAllstage(this.stage[0].id)

                        }).catch()
                },
                getAllstage(id){
                  
                    this.$http.get( 'cloud/course/getCoursesByStage?stage='+id)
                        .then( (response)=> {
                            this.courselist = response.data.data;


                        }).catch()
                },
                getleavel(id,name){
                   
                    var htmlTag='';
                    for (var index = 0; index < name.length; index++) {
                       var char = name[index];
                       htmlTag+= '<em>'+char+'</em>／';
                    }

                    this.title=htmlTag;
                    this.getAllstage(id)
                }
     },
            mounted() {
                this.getstage();
              
            }
}
</script>
<style scoped>
@import '../assets/css/course.css';
@import '../assets/css/tabs.css';
</style>
